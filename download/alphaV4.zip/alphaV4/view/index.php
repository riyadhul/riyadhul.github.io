<?php

include_once("../core/func.php");
e502();



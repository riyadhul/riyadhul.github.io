<?php 
session_start();
// hide all error
error_reporting(0);
// protect .php
$get_self = explode("/",$_SERVER['PHP_SELF']);
$self[] = $get_self[count($get_self)-1];

if($self[0] !== "index.php"  && $self[0] !==""){
    include_once("../core/func.php");

    e502();

}else{


    $is_mobile = $_GET['mobile'];


if(!isset($is_mobile)){
  

    $report_ma = "sidenav_active";
    
    include_once("view/header_html.php");
    include_once("view/menu.php");
    
    



?>
<div class="main">
    <div class="row">
        <div class="col-12">
            <div class="card ">
            <div class="card-header">
                <h3>Selling Report &nbsp; <span id="loadingX"></span></h3>
            </div>
            <div class="card-body">
            <div class="row">
                <div class="col-12 mr-b-10">
                    <div class="btn-group">
                        <button class="bg-btn-group" onclick="loadSReport()" id="btn-selling-report"><i class="fa fa-list" ></i> Report</button> 
                        <button class="bg-btn-group" onclick="loadReoprResume()" id="btn-report-resume"><i class="fa fa-chars" ></i> Resume</button>
                        
                    </div>
                    
                </div>
                
                <div class="col-12 hide" id="selling-report">
                    <div class="">
                    <div class="btn-group">
                        <button class="bg-btn-group table-total" id="total-report" >&nbsp;</button>
                                           
                        <button class="bg-btn-group" onclick="loadSReport('true')"><i class="fa fa-refresh" ></i></button>
                        <input data-toggle="datepicker" type="text" autocomplete = "off" id="filter-report" onkeyup="filterTableReport('report','searchReport',this.value,'count-report')" placeholder="Filter" />
                        <button class="bg-btn-group" onclick="filterTableReport('report','filter-report','','count-report')" title="Clear filter"><i class="fa fa-filter" ></i></button>
                        <div data-toggle="datepicker"></div>

                    </div>
                    
                    </div>
                    <div class="card-fixed mr-t-10">
                    <div style="float: right; font-size:16px; font-weight:bold;"><span id="count-report"></span></div>
                    <table class="table table-bordered table-hover sreport">
                        
                        <thead>
                            <tr> 				
                                <th></th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Username</th>
                                <th>Profile</th>
                                <th>Comment</th>
                                <th class="text-right">Price</th>
                                
                            </tr>
                        </thead>
                        <tbody id="report">
                            <tr>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                
                            </tr>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            </div>
            <div class="card-footer"><span id="loading"></span> </div>
            </div>
        </div>
    </div>
</div>
<?php 

}else if(isset($is_mobile)){ 

  include_once("view/header_html.php");

  ?>

<div class="main-mobile">
    <div class="row">
        <div class="col-12">
            <div class="card ">
            <div class="card-header">
                <h3>Hotspot &nbsp; <span id="loadingX"></span></h3>
            </div>
            <div class="card-body">
            
            </div>
            <div class="card-footer"><span id="loading"></span> </div>
            </div>
        </div>
    </div>
</div>


<?php } ?>
<script>
    
$(document).ready(function() {
// $("#user-profiles").removeClass('hide').addClass('block');
setTimeout(function(){
        setTimeout(function(){
            loadSReport()
        },100)
    $("#report").html("")
},1)



    $(".sreport").fancyTable({
    inputId: "searchReport",          
    sortColumn:1,
    pagination: true,
    perPage:12,
    globalSearch:true,
    paginationClass: "btn btn-bordered",
    paginationClassActive:"bg-primary",

    });  

   

})


</script>

<?php
include_once("view/footer_html.php");
}
?>

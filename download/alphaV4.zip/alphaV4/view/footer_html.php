<?php 
session_start();
// hide all error
error_reporting(0);
// protect .php
$get_self = explode("/",$_SERVER['PHP_SELF']);
$self[] = $get_self[count($get_self)-1];

if($self[0] !== "index.php"  && $self[0] !==""){
    include_once("../core/func.php");

    e502();

}else{

    $curr = "Rp";

    $randTime = str_replace(" ","_",date("Y-m-d H:i:s"));

    $iface = "ether1";
    

?>
<script>
	
		localStorage.setItem("?<?= $_SESSION['m_user'] ?>Curr","<?= $curr ?>");

        localStorage.setItem("?<?= $_SESSION['m_user'] ?>Iface","<?= $iface ?>");
        
        localStorage.setItem("?<?= $_SESSION['m_user'] ?>_theme","<?= $theme ?>")


</script>

<script src="assets/js/mikhmon.js?t=<?= $randTime ?>"></script>
<script src="assets/js/format.js?t=<?= $randTime ?>"></script>
<script src="assets/js/func.js?t=<?= $randTime ?>"></script>
<script src="assets/js/isMobile.js?t=<?= $randTime ?>"></script>
<script src="assets/js/highcharts/highcharts.js"></script>
<script src="assets/js/highcharts/highcharts.theme.js"></script>
<script src="assets/js/fancyTable.js"></script>


</body>
</html>

<?php } ?>
<?php

include_once("func.php");
e502();
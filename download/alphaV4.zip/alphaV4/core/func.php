<?php 
error_reporting(0);
forbPHP();

// Route
function route($m_user,$page,$s_page){

    if (!array_key_exists($page,$s_page)){
        e404();

    }else if ($GLOBALS['n_uri_path'] > $GLOBALS['max_path']){
        e404();

    }else if ($GLOBALS['n_uri_path'] == $GLOBALS['max_path'] &&  $GLOBALS['act'] !== ""){
        e404();

    }else if (array_key_exists($page,$s_page)){
    
        include_once($s_page[$page]);

    }else{
        e404();
    }

}


// Forbidden 403
function forbPHP(){
    $get_self = explode("/",$_SERVER['PHP_SELF']);
    $self[] = $get_self[count($get_self)-1];

    if($self[0] !== "index.php"  && $self[0] !==""){
        e502();

    }
}


//err page

function e502(){
    header('HTTP/1.0 502 Connection refused', true, 502);

    echo '<html>
<head>
<title>502 Connection refused</title>
</head>
<body>
<center><h1>502 Connection refused</h1></center>
<hr>
<center>mikhmon</center>
<!-- default "Connection refused" response (502) -->
</body>
</html>';
    die();
}

function e404(){
    header('HTTP/1.0 404 Not Found', true, 404);
    echo '<html>
<head>
<title>404 Not Found</title>
</head>
<body>
<center><h1>404 Not Found</h1></center>
<hr>
<center>mikhmon</center>
<!-- default "Not Found" response (404) -->
</body>
</html>';
    die();
}

// encrypt decript
